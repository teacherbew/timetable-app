from typing import List, Optional

from pydantic import BaseModel


# --- Teacher Schemas ---
class TeacherBase(BaseModel):
    code: str  # รหัสครูของโรงเรียน
    name: str
    email: Optional[str] = None


class TeacherCreate(TeacherBase):
    pass


class TeacherResponse(BaseModel):
    id: int
    code: Optional[str] = None  # เผื่อแถวเก่าที่สร้างก่อนมีคอลัมน์นี้
    name: str
    email: Optional[str] = None

    class Config:
        from_attributes = True


# --- Subject Schemas ---
class SubjectBase(BaseModel):
    code: str
    name: str


class SubjectCreate(SubjectBase):
    pass


class SubjectResponse(SubjectBase):
    id: int

    class Config:
        from_attributes = True


# --- Room Schemas ---
class RoomBase(BaseModel):
    code: str  # เลขห้องของโรงเรียน
    name: Optional[str] = None
    capacity: Optional[int] = None


class RoomCreate(RoomBase):
    pass


class RoomResponse(BaseModel):
    id: int
    code: Optional[str] = None  # เผื่อแถวเก่าที่สร้างก่อนมีคอลัมน์นี้
    name: Optional[str] = None
    capacity: Optional[int] = None

    class Config:
        from_attributes = True


# --- ClassGroup Schemas (ระดับชั้น/ห้องเรียนนักเรียน) ---
class ClassGroupBase(BaseModel):
    name: str  # เช่น "ม.1/1"
    level: str  # เช่น "ม.1"


class ClassGroupCreate(ClassGroupBase):
    pass


class ClassGroupResponse(ClassGroupBase):
    id: int

    class Config:
        from_attributes = True


# --- TimetableSlot Schemas ---
class TimetableSlotBase(BaseModel):
    day: str
    period: int
    teacher_id: int
    subject_id: int
    room_id: int
    class_group_id: int


class TimetableSlotCreate(TimetableSlotBase):
    pass


class TimetableSlotResponse(BaseModel):
    id: int
    day: str
    period: int
    teacher: Optional[TeacherResponse] = None
    subject: Optional[SubjectResponse] = None
    room: Optional[RoomResponse] = None
    class_group: Optional[ClassGroupResponse] = None

    class Config:
        from_attributes = True


# --- Wrapper for paginated schedule responses ---
class ScheduleDataContent(BaseModel):
    total_items: int
    page: int = 1
    limit: int = 10
    total_pages: int = 1
    items: List[TimetableSlotResponse]


class ScheduleResponseWrapper(BaseModel):
    source: str
    data: ScheduleDataContent
